---
name: Supify Visual Language
colors:
  surface: '#fdf8f8'
  surface-dim: '#ddd9d8'
  surface-bright: '#fdf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f2'
  surface-container: '#f1edec'
  surface-container-high: '#ebe7e6'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#444748'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c9c6c5'
  secondary: '#615e57'
  on-secondary: '#ffffff'
  secondary-container: '#e7e2d8'
  on-secondary-container: '#67645d'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d1b1a'
  on-tertiary-container: '#868381'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c9c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#e7e2d8'
  secondary-fixed-dim: '#cac6bd'
  on-secondary-fixed: '#1d1c16'
  on-secondary-fixed-variant: '#494740'
  tertiary-fixed: '#e6e1df'
  tertiary-fixed-dim: '#cac6c3'
  on-tertiary-fixed: '#1d1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#fdf8f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
  brand-pink: '#ff4d8b'
  brand-teal: '#1a3a3a'
  brand-lavender: '#b8a4ed'
  brand-peach: '#ffb084'
  brand-ochre: '#e8b94a'
  brand-mint: '#a4d4c5'
  brand-coral: '#ff6b5a'
  surface-soft: '#faf5e8'
  surface-card: '#f5f0e0'
  surface-strong: '#ebe6d6'
  hairline: '#e5e5e5'
  body-muted: '#6a6a6a'
typography:
  display-xl:
    fontFamily: Rubik
    fontSize: 72px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: -2.5px
  display-xl-mobile:
    fontFamily: Rubik
    fontSize: 36px
    fontWeight: '500'
    lineHeight: '1.1'
    letterSpacing: -1px
  display-lg:
    fontFamily: Rubik
    fontSize: 56px
    fontWeight: '500'
    lineHeight: '1.05'
    letterSpacing: -2px
  display-md:
    fontFamily: Rubik
    fontSize: 40px
    fontWeight: '500'
    lineHeight: '1.1'
    letterSpacing: -1px
  display-sm:
    fontFamily: Rubik
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.15'
    letterSpacing: -0.5px
  title-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.3px
  title-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.4'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.55'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.55'
  label-uppercase:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 1.5px
  button:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  md: 16px
  lg: 24px
  xl: 32px
  section: 96px
  container-max: 1280px
---

## Brand & Style

This design system translates the playful, hand-crafted energy of the reference style into a professional B2B context for supplier discovery and verification. The brand personality is **trustworthy yet playful and modern**, moving away from the cold, clinical grids typical of supply chain software in favor of a warm, approachable "claymation" aesthetic.

The design style is **Modern-Tactile**. It prioritizes a "warm cream canvas" over sterile whites and uses generous roundedness to evoke a sense of friendliness and ease of use. Large, rounded display typography combined with saturated, single-color feature cards creates a distinctive visual rhythm that balances professional reliability with a fresh, contemporary energy. Key visual interest is driven by 3D illustrations that provide depth and personality without relying on traditional drop shadows or complex gradients.

## Colors

The palette is anchored by a warm **Canvas** background (#fffaf0), which differentiates the platform from competitors' cool-gray interfaces. High-contrast **Ink** (#0a0a0a) provides professional weight for typography and primary actions.

The "Brand Voltage" is delivered through a 6-color saturated palette used exclusively for feature cards and pricing signals.
- **Teal** serves as the primary signal for "Featured" or "Enterprise" tiers.
- **Pink, Lavender, Peach, and Ochre** are rotated to categorize different supplier verification modules (e.g., Pink for logistics, Lavender for AI-risk assessment).
- **Hairline** borders are used sparingly to define boundaries on secondary surfaces without adding visual clutter.
- **Semantic colors** follow industry standards for success, warning, and error but should be used within the context of the warm canvas.

## Typography

The typographic system utilizes a "rounded display" vs. "utilitarian body" split. **Rubik** (or a similar rounded sans) is used for headlines to mirror the "Clay" aesthetic, while **Inter** provides the necessary legibility for data-heavy supply chain information.

**Key Rules:**
- **Display Headlines:** Must be weight 500 only. Never use 700+ weights as they become too aggressive. Negative letter-spacing is required for all display levels to create a tight, editorial feel.
- **Body Text:** Inter is used for all functional UI, running text, and buttons.
- **Section Labels:** Small caps/uppercase Inter with generous letter-spacing is used to tag sections and feature categories.
- **Mobile Scaling:** Headline sizes drop significantly on mobile (e.g., 72px to 36px) to maintain readability on smaller canvases.

## Layout & Spacing

This design system uses a **Fluid Grid** model with a fixed maximum container width of 1280px. The layout is defined by generous vertical rhythm to ensure the saturated cards have room to breathe.

**Rhythm and Padding:**
- **Section Spacing:** A strict 96px vertical margin separates major content bands.
- **Internal Card Padding:** Feature cards use 32px (xl) padding, while secondary/content cards use 24px (lg).
- **Responsive Reflow:** Feature grids transition from 3-up on desktop to 2-up on tablet and 1-up on mobile. 
- **Hero Construction:** Uses a 7/5 column split on desktop, placing typography on the left and 3D illustration artifacts on the right. This stacks vertically on mobile devices.

## Elevation & Depth

Depth in this system is achieved through **Tonal Layers** and color contrast rather than traditional shadow-based elevation.

- **Flat Canvas:** The background remains a flat #fffaf0.
- **Color Blocks:** Saturated feature cards create a "cut-out" or "layered" effect purely through high-contrast fills against the cream canvas.
- **Soft Hairlines:** 1px borders (#e5e5e5) provide structural definition for inputs and secondary cards without introducing weight.
- **3D Illustrations:** Depth is primarily introduced via 3D rendered assets (mascot characters or abstract supply chain icons). These assets should feel tactile and "squishy" (clay-like) to reinforce the brand narrative.
- **Interactive States:** Hover effects should be subtle, such as a slight thickening of the hairline border or a very low-alpha ambient shadow.

## Shapes

The shape language is consistently **Rounded**, echoing the curves of the display typography and 3D illustrations.

- **Standard Buttons & Inputs:** 12px (rounded-md) for a modern, friendly feel that remains functional.
- **Content Cards:** 16px (rounded-lg) for testimonials and data cards.
- **Feature Cards:** 24px (rounded-xl) for large, saturated brand cards. This exaggerated radius emphasizes the playful nature of the feature highlights.
- **Badges/Pills:** Full rounded (pill-shaped) for status indicators and category tags.

## Components

### Buttons
- **Primary:** Near-black background, white text. 12px border radius. Used for the main "Verify Supplier" or "Get Started" actions.
- **Secondary:** Cream background with a 1px hairline border. Used for "Cancel" or "Learn More."
- **On-Color:** White background with ink text. Used specifically when a button is placed inside a saturated (Pink/Teal) feature card.

### Feature Cards
These are the signature component. They feature a full-color fill from the brand palette.
- **Pink/Teal Cards:** Use white text for contrast.
- **Lavender/Peach/Ochre Cards:** Use ink text.
- Each card should contain a headline, a short description, and a "UI Fragment"—a small-scale mockup of the Supify platform (e.g., a verified badge or a risk-score chart).

### Pricing Tiers
- Standard tiers use the Cream Card style (surface-card) with a hairline border.
- The **Featured Tier** uses a Brand Teal background to immediately draw the eye as the primary value proposition.

### Inputs
Text fields use the cream canvas background with a 1px hairline border. On focus, the border transitions to a 2px ink stroke to provide clear accessibility and state feedback.

### Navigation & Footer
- **Navigation:** Persistent cream bar with centered links and a primary CTA on the right.
- **Footer:** Remains cream-tinted (#faf5e8). **Never use a dark footer.** This maintains the warmth of the brand until the very end of the user's scroll. Use a 3D landscape illustration at the base of the footer to ground the page.